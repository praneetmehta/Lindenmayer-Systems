var struct_point =
[
    [ "Point", "struct_point.html#ad92f2337b839a94ce97dcdb439b4325a", null ],
    [ "Point", "struct_point.html#a483cf6bf601889eb922e89f5820045c1", null ],
    [ "X", "struct_point.html#a9a3d900d37caa93c8266045f9a15ddfd", null ],
    [ "Y", "struct_point.html#afd3632a85aefc15a129a8ebc4b8412b9", null ]
];