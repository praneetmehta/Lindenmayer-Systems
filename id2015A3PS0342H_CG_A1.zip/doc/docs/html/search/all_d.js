var searchData=
[
  ['x',['X',['../struct_point.html#a9a3d900d37caa93c8266045f9a15ddfd',1,'Point']]]
];
