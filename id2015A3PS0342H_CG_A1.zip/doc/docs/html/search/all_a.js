var searchData=
[
  ['setcolor',['setColor',['../class_draw_util.html#a7af56ab1f6abf214d9508366044ad701',1,'DrawUtil']]],
  ['startwindow',['StartWindow',['../class_draw_util.html#ac67eebabd1b221eb8d91ae3fd03aed7e',1,'DrawUtil']]],
  ['stayawake',['Stayawake',['../class_draw_util.html#ada6850c46fbb4986d78bbc72bc61ad57',1,'DrawUtil']]],
  ['switchoctantfromzero',['switchOctantFromZero',['../class_draw_util.html#af7ced646e997e6a7187f13224a0ddadb',1,'DrawUtil']]],
  ['switchoctanttozero',['switchOctantToZero',['../class_draw_util.html#a2d2d468d49c95fefdbb69de84f3135c2',1,'DrawUtil']]]
];
