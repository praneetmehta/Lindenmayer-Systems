var searchData=
[
  ['y',['Y',['../struct_point.html#afd3632a85aefc15a129a8ebc4b8412b9',1,'Point']]]
];
