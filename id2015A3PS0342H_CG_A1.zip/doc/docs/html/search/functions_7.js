var searchData=
[
  ['rgb',['RGB',['../struct_draw_util_1_1_r_g_b.html#afc69c68816cbfd81a809d2361d969b61',1,'DrawUtil::RGB::RGB()'],['../struct_draw_util_1_1_r_g_b.html#a971430cf0507570da513b2d99d245531',1,'DrawUtil::RGB::RGB(double _r, double _g, double _b)']]]
];
